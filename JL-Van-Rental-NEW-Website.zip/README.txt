J&L VAN RENTAL WEBSITE

1. Upload ONLY index.html to the main/root folder of your GitHub repository.
2. Click Commit changes.
3. Go to Settings > Pages > Deploy from a branch > main > /(root) > Save.
4. Wait several minutes and use the Pages URL GitHub provides.

The booking form opens an email app; customers must send the email.
